# Owen Kroeger
# My Own Work

import random

numSet = set();

for i in range(3):
    numSet.add(random.randrange(1,100,1))


print(numSet)
